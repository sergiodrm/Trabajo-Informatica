#include "acorazado.h"

Acorazado::Acorazado(): Nave(100, 100, 14, 28, make_pair(0, 0))
{
    this->imagenes[Mov::Up] = QPixmap(":/images/acorazado_U.png");
    this->imagenes[Mov::Down] = QPixmap(":/images/acorazado_D.png");
    this->imagenes[Mov::Left] = QPixmap(":/images/acorazado_L.png");
    this->imagenes[Mov::Right] = QPixmap(":/images/acorazado_R.png");
    this->key = Mov::Down;
}

void Acorazado::fortificacion() {

}
