#ifndef ENEMIGO_H
#define ENEMIGO_H

#include <iostream>
#include <time.h>
#include "nave.h"
#include "gamewindow.h"


using namespace std;

class Enemigo : public Nave
{
public:
    Enemigo();
    void mover(pair<int, int> pos);

    int getRango_vision();
    void setRango_vision(int r);

protected:
    int rango_vision;
};

#endif // ENEMIGO_H
