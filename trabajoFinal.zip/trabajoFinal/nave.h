#ifndef NAVE_H
#define NAVE_H

#include <string.h>
#include <QPixmap>
#include <QLabel>
#include <QDir>

#include <iostream>

class GameWindow; // Declaración directa

using namespace std;

class Nave{

private:
    char key;
    map<char, QPixmap> imagenes;
    int vida;
    int escudo;
    int ataque;
    int ataque_especial;
    pair <int, int> pos;

public:
    Nave();
    Nave(int vida, int esc, int ataq, int ataq_es, pair<int, int> pos);
    Nave(Nave &n);
    ~Nave();

    int getVida();
    int getAtaque();
    int getAtaque_especial();
    int getEscudo();
    pair <int,int> getPos();
    char getKey();
    map<char, QPixmap> getImagenes();
    QPixmap getImagen();

    int getX();
    int getY();

    void setVida(int value);
    void setAtaque(int value);
    void setAtaque_especial(int value);
    void setEscudo(int value);
    void setPos(pair <int,int> pos);
    void setKey(char key);

    void mover(char mov);
    void atacar(Nave *);

};

#endif
