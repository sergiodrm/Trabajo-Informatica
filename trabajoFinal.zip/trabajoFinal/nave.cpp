#include "nave.h"
#include "gamewindow.h"

Nave::Nave()
{
    vida = 50;
    escudo = 20;
    ataque = 4;
    ataque_especial = 4;
    pos.first = 0;
    pos.second = 0;

    this->imagenes['U'] = QPixmap(":/images/caza_U.png");
    this->imagenes['D'] = QPixmap(":/images/caza_D.png");
    this->imagenes['L'] = QPixmap(":/images/caza_L.png");
    this->imagenes['R'] = QPixmap(":/images/caza_R.png");
    this->key = 'D';
}

Nave::Nave(int vid, int esc, int ataq, int ataq_es, pair<int, int> pos){
    vida = vid;
    escudo = esc;
    ataque = ataq;
    ataque_especial = ataq_es;
    if (pos.first >= 0 && pos.first < COLUMNAS){
        this->pos.first = pos.first;
    }else this->pos.first = 0;
    if (pos.second >= 0 && pos.second < FILAS){
        this->pos.second = pos.second;
    }else this->pos.second = 0;

    this->imagenes['U'] = QPixmap(":/images/caza_U.png");
    this->imagenes['D'] = QPixmap(":/images/caza_D.png");
    this->imagenes['L'] = QPixmap(":/images/caza_L.png");
    this->imagenes['R'] = QPixmap(":/images/caza_R.png");
    this->key = 'D';

}

Nave::Nave(Nave &n) {
    this->vida = n.vida;
    this->escudo = n.escudo;
    this->ataque = n.ataque;
    this->ataque_especial = n.ataque_especial;
    if (pos.first >= 0 && pos.first < COLUMNAS){
        this->pos.first = pos.first;
    }else this->pos.first = 0;
    if (pos.second >= 0 && pos.second < FILAS){
        this->pos.second = pos.second;
    }else this->pos.second = 0;

    this->key = n.key;
    this->imagenes = n.imagenes;
}

Nave::~Nave(){

}

// Metodos GET
int Nave::getVida() { return vida; }
int Nave::getAtaque() { return ataque; }
int Nave::getAtaque_especial() { return ataque_especial; }
int Nave::getEscudo() { return escudo; }
pair<int,int> Nave::getPos() { return this->pos;  }
QPixmap Nave::getImagen() { return this->imagenes[this->key]; }
char Nave::getKey() { return this->key; }
map<char, QPixmap> Nave::getImagenes() { return this->imagenes; }
int Nave::getX() { return this->pos.first; }
int Nave::getY() { return this->pos.second; }

// Metodos SET
void Nave::setVida(int value) {
    if ( value > 0 )
        this->vida = value;
}

void Nave::setAtaque(int value){
    if ( value > 0 )
        this->ataque = value;
}

void Nave::setAtaque_especial(int value){
    if ( value > 0 )
        this->ataque_especial = value;
}

void Nave::setEscudo(int value){
    if ( value > 0 )
        this->escudo = value;
}

void Nave::setPos(pair<int, int> pos){
    if (pos.first >= 0 && pos.first < COLUMNAS){
        this->pos.first = pos.first;
    }else this->pos.first = 0;
    if (pos.second >= 0 && pos.second < FILAS){
        this->pos.second = pos.second;
    }else this->pos.second = 0;
}


void Nave::mover(char mov){
    //Según el char, se modifica la posición de la nave en una de las 4 posibles direcciones
    if (mov == 'U' && this->pos.second - 1 >= 0) {
        this->pos.second--;
        this->key = 'U';

    }else if (mov == 'D' && this->pos.second + 1 < FILAS){
        this->pos.second++;
        this->key = 'D';

    }else if (mov == 'R' && this->pos.first + 1 < COLUMNAS) {
        this->pos.first++;
        this->key = 'R';

    }else if (mov == 'L' && this->pos.first - 1 >= 0) {
        this->pos.first--;
        this->key = 'L';
    }


}
