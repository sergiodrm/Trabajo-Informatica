#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QWidget>
#include <QPainter>
#include <QKeyEvent>
#include <nave.h>
#include <iostream>
#include <QLabel>
#include <QCloseEvent>
#include <QMessageBox>

#define FILAS 10
#define COLUMNAS 10

using namespace std;

namespace Ui {
class GameWindow;
}

class GameWindow : public QWidget
{
    Q_OBJECT

public:
    explicit GameWindow(QWidget *parent = 0);
    GameWindow(GameWindow& g);
    ~GameWindow();

    void paintEvent(QPaintEvent *event);
    void keyPressEvent(QKeyEvent *event);

    int getLim_der();
    int getLim_izq();
    int getLim_sup();
    int getLim_inf();

    void actualizarPosiciones();
    void closeEvent(QCloseEvent *event);


private slots:
    void on_upButton_clicked();

    void on_leftButton_clicked();

    void on_downButton_clicked();

    void on_rightButton_clicked();

private:
    Ui::GameWindow *ui;
    Nave nave;
    QLabel lay;
    int lim_der;
    int lim_izq;
    int lim_sup;
    int lim_inf;

};

#endif // GAMEWINDOW_H
