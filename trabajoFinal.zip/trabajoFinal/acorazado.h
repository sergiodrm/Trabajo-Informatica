#ifndef ACORAZADO_H
#define ACORAZADO_H

#include "nave.h"


class Acorazado : public Nave
{
public:
    Acorazado();
    void fortificacion();
};

#endif // ACORAZADO_H
