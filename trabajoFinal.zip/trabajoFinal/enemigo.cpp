#include "enemigo.h"

Enemigo::Enemigo(): Nave()
{
    this->rango_vision = 3;

}

void Enemigo::mover(pair<int, int> pos) {

    if ( abs(this->pos.first - pos.first) <= this->rango_vision &&
         abs(this->pos.second - pos.second) <= this->rango_vision)
    {

        if ( abs(this->pos.first - pos.first) < abs(this->pos.second - pos.second) )
        {

            if ( this->pos.first - pos.first > 0 &&
                 this->pos.first + this->velocidad < COLUMNAS )
            {

                this->pos.first += this->velocidad;

            }else if ( this->pos.first - pos.first < 0 &&
                       this->pos.first - this->velocidad >= 0 )
            {
                this->pos.first -= this->velocidad;
            }
        }else
        {
            if ( this->pos.second - pos.second > 0 &&
                 this->pos.second + this->velocidad < FILAS )
            {

                this->pos.second += this->velocidad;

            }else if ( this->pos.second - pos.second < 0 &&
                       this->pos.second - this->velocidad >= 0 )
            {
                this->pos.second -= this->velocidad;
            }
        }
    }else
    {
        srand(time(NULL));
        int rnd = rand()%4;
        switch ( rnd )
        {
        case Mov::Down:
            if ( this->pos.second + this->velocidad < FILAS )
                this->pos.second += this->velocidad;
            break;
        case Mov::Left:
            if ( this->pos.first - this->velocidad >= 0 )
                this->pos.first -= this->velocidad;
            break;
        case Mov::Right:
            if ( this->pos.first + this->velocidad < COLUMNAS )
                this->pos.first += this->velocidad;
            break;
        case Mov::Up:
            if ( this->pos.second - this->velocidad >= 0 )
                this->pos.second -= this->velocidad;
            break;
        }
    }
}

int Enemigo::getRango_vision() { return this->rango_vision; }
void Enemigo::setRango_vision(int r) { this->rango_vision = r; }
