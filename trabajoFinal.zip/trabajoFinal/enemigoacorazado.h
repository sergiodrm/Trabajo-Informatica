#ifndef ENEMIGOACORAZADO_H
#define ENEMIGOACORAZADO_H


class EnemigoAcorazado
{
public:
    EnemigoAcorazado();
};

#endif // ENEMIGOACORAZADO_H
