#ifndef ENEMIGOCAZA_H
#define ENEMIGOCAZA_H


class EnemigoCaza
{
public:
    EnemigoCaza();
};

#endif // ENEMIGOCAZA_H