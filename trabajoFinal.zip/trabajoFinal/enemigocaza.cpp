#include "enemigocaza.h"

EnemigoCaza::EnemigoCaza()
{

}
