#ifndef ENEMIGODESTRUCTOR_H
#define ENEMIGODESTRUCTOR_H


class EnemigoDestructor
{
public:
    EnemigoDestructor();
};

#endif // ENEMIGODESTRUCTOR_H