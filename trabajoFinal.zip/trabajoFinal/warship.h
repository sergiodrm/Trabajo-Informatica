#ifndef WARSHIP_H
#define WARSHIP_H

#include "nave.h"


class Warship : public Nave
{
public:
    Warship();
    void potenciarAtaque();
};

#endif // WARSHIP_H
