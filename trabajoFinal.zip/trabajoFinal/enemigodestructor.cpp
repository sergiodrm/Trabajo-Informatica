#include "enemigodestructor.h"

EnemigoDestructor::EnemigoDestructor()
{

}
