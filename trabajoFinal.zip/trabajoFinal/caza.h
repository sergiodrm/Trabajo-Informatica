#ifndef CAZA_H
#define CAZA_H

#include "nave.h"


class Caza : public Nave
{
public:
    Caza();
    void activarTurbo();
};

#endif // CAZA_H
