#include "game.h"

template <class N>
Game<N>::Game()
{
    game_over = false;
    this->turno = 1;

    /*
     * Inicialización aleatoria de los obstáculos en el escenario de juego
     */
    //Esta función debe ejecutarse antes de crear las naves enemigas
    int i = 0;
    int posx, posy;
    int aux;
    while (i < this->n_bloqueos){
        aux = 0;
        posx = rand() % this->n_bloqueos;
        posy = rand() % this->n_bloqueos;
        vector< pair<int, int> >::iterator item;
        for (item = this->bloqueos.begin(); item != this->bloqueos.end(); item++){
            if ( make_pair(posx, posy) == *item ){
                aux = 1;
            }
        }
        /* El obstáculo que se genere no puede bloquear la casilla de salida
         * ni formar círculos encerrando casillas
         */
        if (!((posx == 0 && posy == 0) || (posx == 1 && posy == 0) || (posx == 0 && posy == 1)) && aux == 0){
            this->bloqueos.push_back(  make_pair(posx, posy) );
            this->gamewindow.introducirBloqueo(make_pair(posx, posy));
            i++;
        }
    }

    /*-----------------------------------------------------*/

    /*
    int px = this->gamewindow.getLim_izq() + this->jugador.getX()*floor((this->gamewindow.getLim_der() - this->gamewindow.getLim_izq())/COLUMNAS);
    int py = this->gamewindow.getLim_sup() + this->jugador.getY()*floor((this->gamewindow.getLim_inf() - this->gamewindow.getLim_sup())/FILAS);
    int qx = floor(floor((this->gamewindow.getLim_der() - this->gamewindow.getLim_izq())/COLUMNAS - this->jugador.getImagen().width())/2) + px;
    int qy = floor(floor((this->gamewindow.getLim_inf() - this->gamewindow.getLim_sup())/FILAS - this->jugador.getImagen().height())/2) + py;
    */

    QLabel lay;
    pair<int, int> pos_tab = this->gamewindow.calculoPosicion(this->jugador.getPos(),
                                                              make_pair(this->jugador.getImagen().width(),
                                                                        this->jugador.getImagen().height()));
    lay.setParent(&(this->gamewindow));
    lay.setGeometry(pos_tab.first, pos_tab.second, this->jugador.getImagen().width(), this->jugador.getImagen().height());
    lay.setPixmap(this->jugador.getImagen());

    this->gamewindow.setLabel_jugador(&lay);

    this->gamewindow.setSaludBar(this->jugador.getVida());
    this->gamewindow.setEscudoBar(this->jugador.getEscudo());
    this->gamewindow.setAtqBar(this->jugador.getAtaque());
    this->gamewindow.setAtqEspBar(this->jugador.getAtaque_especial());
    this->gamewindow.setTurnoLCD(this->turno);
    this->gamewindow.setPosXLCD(this->jugador.getX());
    this->gamewindow.setPosYLCD(this->jugador.getY());
    this->gamewindow.setPALCD(this->jugador.getPuntos_accion());
}

template <class N>
GameWindow Game<N>::getGameWindow() { return this->gamewindow; }

template <class N>
bool Game<N>::getGameOver() { return this->game_over; }

template <class N>
void Game<N>::setGameOver(bool game_over) { this->game_over = game_over; }

template <class N>
N Game<N>::getJugador() { return this->jugador; }

template <class N>
void Game<N>::setJugador(N jugador) { this->jugador = jugador; }

template <class N>
void Game<N>::iniciarGame(QApplication *a){

    this->gamewindow.show();

    while ( !this->game_over && this->gamewindow.isVisible() ) {
        a->processEvents();
        this->actualizarGame();
        Sleep(50);
    }

}

template <class N>
bool Game<N>::comprobarPosicion(int mov)
{
    pair<int, int> avance = this->jugador.getPos();
    switch ( mov )
    {
    case Mov::Up:
        avance.second -= this->jugador.getVelocidad();
        break;
    case Mov::Down:
        avance.second += this->jugador.getVelocidad();
        break;
    case Mov::Left:
        avance.first -= this->jugador.getVelocidad();
        break;
    case Mov::Right:
        avance.first += this->jugador.getVelocidad();
        break;
    }
    if ( avance.first >= 0 && avance.first < COLUMNAS &&
         avance.second >= 0 && avance.second < FILAS )
    {
        vector<pair<int, int>>::iterator item = this->bloqueos.begin();
        while (item != this->bloqueos.end() && !(item->first == avance.first && item->second == avance.second) )
        {
            item++;
        }
        if ( item != this->bloqueos.end() )
            return false;
    }else return false;

    return true;
}

template <class N>
void Game<N>::actualizarGame(){

    /* Mover la jugador del jugador */
    while (!this->gamewindow.emptyMov()) {
        if ( this->jugador.getPuntos_accion() > 0 && this->comprobarPosicion(this->gamewindow.frontMov()) )
        {
            this->jugador.mover(this->gamewindow.frontMov());
            this->gamewindow.setPosXLCD(this->jugador.getX());
            this->gamewindow.setPosYLCD(this->jugador.getY());
            this->gamewindow.setPALCD(this->jugador.getPuntos_accion());
        }
        this->gamewindow.popMov();

        QLabel lay;
        pair<int, int> pos_tab = this->gamewindow.calculoPosicion(this->jugador.getPos(),
                                                                  make_pair(this->jugador.getImagen().width(),
                                                                            this->jugador.getImagen().height()));
        lay.setParent(&(this->gamewindow));
        lay.setGeometry(pos_tab.first, pos_tab.second, this->jugador.getImagen().width(), this->jugador.getImagen().height());
        lay.setPixmap(this->jugador.getImagen());

        this->gamewindow.setLabel_jugador(&lay);
    }




    /*
     * Hasta aquí mover la jugador del jugador
     */

    if ( this->jugador.getPuntos_accion()  <= 0 ) {


        /* Cuando se acaben de mover los enemigos, vuelve a ser el turno del jugador */
        this->jugador.setPuntos_accion(PA_MAX);


        this->gamewindow.setTurnoLCD(++this->turno);
        this->gamewindow.setPosXLCD(this->jugador.getX());
        this->gamewindow.setPosYLCD(this->jugador.getY());
        this->gamewindow.setPALCD(this->jugador.getPuntos_accion());
    }



    /*
     * Cuando acabe el turno del jugador se moverán los enemigos aquí
     * y habrá que cambiar los QLabel del GameWindow
     */

    /* ---------------------------- */

    /*
     * Actualizar el ListWidget donde se muestra la información de la jugada
     */






    /*
     * El repaint lo último
     */
    this->gamewindow.repaint();
}


template class Game<Acorazado>;
template class Game<Caza>;
template class Game<Destructor>;
template class Game<Warship>;
