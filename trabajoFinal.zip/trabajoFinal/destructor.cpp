#include "destructor.h"

Destructor::Destructor(): Nave(42, 42, 28, 100, make_pair(0, 0))
{
    this->imagenes[Mov::Up] = QPixmap(":/images/destructor_U.png");
    this->imagenes[Mov::Down] = QPixmap(":/images/destructor_D.png");
    this->imagenes[Mov::Left] = QPixmap(":/images/destructor_L.png");
    this->imagenes[Mov::Right] = QPixmap(":/images/destructor_R.png");
    this->key = Mov::Down;

}

void Destructor::potenciarAtqEsp() {

}
