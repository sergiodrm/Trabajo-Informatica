#ifndef ENEMIGOWARSHIP_H
#define ENEMIGOWARSHIP_H


class EnemigoWarship
{
public:
    EnemigoWarship();
};

#endif // ENEMIGOWARSHIP_H