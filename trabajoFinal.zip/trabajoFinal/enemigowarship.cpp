#include "enemigowarship.h"

EnemigoWarship::EnemigoWarship()
{

}
