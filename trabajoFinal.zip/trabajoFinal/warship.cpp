#include "warship.h"

Warship::Warship(): Nave(57, 57, 57, 57, make_pair(0, 0))
{

    this->imagenes[Mov::Up] = QPixmap(":/images/warship_U.png");
    this->imagenes[Mov::Down] = QPixmap(":/images/warship_D.png");
    this->imagenes[Mov::Left] = QPixmap(":/images/warship_L.png");
    this->imagenes[Mov::Right] = QPixmap(":/images/warship_R.png");
    this->key = Mov::Down;

}

void Warship::potenciarAtaque() {

}
