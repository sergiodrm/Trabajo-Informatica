#ifndef DESTRUCTOR_H
#define DESTRUCTOR_H

#include "nave.h"


class Destructor : public Nave
{
public:
    Destructor();
    void potenciarAtqEsp();
};

#endif // DESTRUCTOR_H
