#include "enemigoacorazado.h"

EnemigoAcorazado::EnemigoAcorazado()
{

}
