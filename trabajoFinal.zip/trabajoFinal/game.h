#ifndef GAME_H
#define GAME_H

#include "gamewindow.h"
#include "menuwindow.h"
#include <QApplication>
#include <windows.h>
#include <QKeyEvent>

#include <iostream>
using namespace std;

template <class N>
class Game
{
public:
    Game();
    GameWindow getGameWindow();


    bool getGameOver();
    void setGameOver(bool game_over);

    N getJugador();
    void setJugador(N jugador);

    bool comprobarPosicion(int mov);

    void actualizarGame();

    void iniciarGame(QApplication *a);




private:

    GameWindow gamewindow;

    bool game_over;
    N jugador;
    int turno;
    const int n_bloqueos = 10;
    vector< pair<int, int> > bloqueos;

};

#endif // GAME_H
