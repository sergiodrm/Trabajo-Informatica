#include "gamewindow.h"
#include "ui_gamewindow.h"

GameWindow::GameWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GameWindow)
{
    ui->setupUi(this);

    this->lim_izq = 3;
    this->lim_der = this->width() - 300;
    this->lim_sup = 3;
    this->lim_inf = this->height() - this->lim_sup;

    lay.setParent(this);
    lay.setPixmap(nave.getImagen());

    this->actualizarPosiciones();

}

GameWindow::GameWindow(GameWindow &g) {
    this->ui = g.ui;
}

GameWindow::~GameWindow()
{
    delete ui;
}

void GameWindow::paintEvent(QPaintEvent *event){
    QPainter paint;
    paint.begin(this);

    QPen p;
    p.setWidth(1);
    paint.setPen(p);


    QPoint sup_izq(lim_izq, lim_sup);
    QPoint sup_der(lim_der, lim_sup);
    QPoint inf_izq(lim_izq, lim_inf);
    QPoint inf_der(lim_der, lim_inf);

    paint.drawLine(sup_izq, sup_der);
    paint.drawLine(sup_izq, inf_izq);
    paint.drawLine(inf_izq, inf_der);
    paint.drawLine(sup_der, inf_der);

    for (int i = 1; i < COLUMNAS ; i++) {
        QPoint sup(this->lim_izq + i*floor(this->lim_der/COLUMNAS), this->lim_sup);
        QPoint inf(this->lim_izq + i*floor(this->lim_der/COLUMNAS),
                   this->lim_inf);
        paint.drawLine(sup, inf);
    }
    for (int i = 1; i < FILAS ; i++) {
        QPoint izq(this->lim_izq, this->lim_sup + i*floor(this->lim_inf/FILAS));
        QPoint der(this->lim_der,
                   this->lim_sup + i*floor(this->lim_inf/FILAS));
        paint.drawLine(izq, der);
    }



}

void GameWindow::keyPressEvent(QKeyEvent *event){

    if (event->key() == Qt::Key_Up || event->key() == Qt::Key_W) {
        nave.mover('U');
    }else if (event->key() == Qt::Key_Left || event->key() == Qt::Key_A) {
        nave.mover('L');
    }else if (event->key() == Qt::Key_Right || event->key() == Qt::Key_D) {
        nave.mover('R');
    }else if (event->key() == Qt::Key_Down || event->key() == Qt::Key_S) {
        nave.mover('D');
    }


    this->actualizarPosiciones();


}

int GameWindow::getLim_der() { return this->lim_der; }
int GameWindow::getLim_inf() { return this->lim_inf; }
int GameWindow::getLim_izq() { return this->lim_izq; }
int GameWindow::getLim_sup() { return this->lim_sup; }

void GameWindow::actualizarPosiciones() {
    int px = this->lim_izq + this->nave.getX()*floor((this->lim_der - this->lim_izq)/COLUMNAS);
    int py = this->lim_sup + this->nave.getY()*floor((this->lim_inf - this->lim_sup)/FILAS);
    int qx = floor(floor((this->lim_der - this->lim_izq)/COLUMNAS - this->nave.getImagen().width())/2) + px;
    int qy = floor(floor((this->lim_inf - this->lim_sup)/FILAS - this->nave.getImagen().height())/2) + py;

    this->lay.setGeometry(QRect(qx, qy, this->nave.getImagen().width(), this->nave.getImagen().height()));
    this->lay.setPixmap(this->nave.getImagen());
}

void GameWindow::closeEvent(QCloseEvent *event) {
    QMessageBox::StandardButton rest = QMessageBox::question ( this, tr("Mensaje de advertencia"),
                                                               tr("Si sales perderás la partida...\n¿Estás seguro?\n"),
                                                               QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                               QMessageBox::Yes);
    if (rest != QMessageBox::Yes) {
        event->ignore();
    }else event->accept();

}

void GameWindow::on_upButton_clicked()
{
    this->nave.mover('U');
    this->actualizarPosiciones();
}

void GameWindow::on_leftButton_clicked()
{
    this->nave.mover('L');
    this->actualizarPosiciones();
}

void GameWindow::on_downButton_clicked()
{
    this->nave.mover('D');
    this->actualizarPosiciones();
}

void GameWindow::on_rightButton_clicked()
{
    this->nave.mover('R');
    this->actualizarPosiciones();
}
