#include "gamewindow.h"
#include "ui_gamewindow.h"
#include "game.h"


GameWindow::GameWindow( QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GameWindow)
{
    ui->setupUi(this);
    connect(ui->upButton, SIGNAL(clicked()), this, SLOT(moverUp()));
    connect(ui->downButton, SIGNAL(clicked()), this, SLOT(moverDown()));
    connect(ui->leftButton, SIGNAL(clicked()), this, SLOT(moverLeft()));
    connect(ui->rightButton, SIGNAL(clicked()), this, SLOT(moverRight()));


    this->label_jugador.setParent(this);
}


GameWindow::GameWindow(GameWindow& g) {
    this->ui = g.ui;
}


GameWindow::~GameWindow()
{
    delete ui;
}


void GameWindow::paintEvent(QPaintEvent *event){
    QPainter paint;
    paint.begin(this);

    QPen p;
    p.setWidth(1);
    paint.setPen(p);


    QPoint sup_izq(lim_izq, lim_sup);
    QPoint sup_der(lim_der, lim_sup);
    QPoint inf_izq(lim_izq, lim_inf);
    QPoint inf_der(lim_der, lim_inf);

    paint.drawLine(sup_izq, sup_der);
    paint.drawLine(sup_izq, inf_izq);
    paint.drawLine(inf_izq, inf_der);
    paint.drawLine(sup_der, inf_der);

    for (int i = 1; i < COLUMNAS ; i++) {
        QPoint sup(this->lim_izq + i*floor(this->lim_der/COLUMNAS),
                   this->lim_sup);
        QPoint inf(this->lim_izq + i*floor(this->lim_der/COLUMNAS),
                   this->lim_inf);
        paint.drawLine(sup, inf);
    }
    for (int i = 1; i < FILAS ; i++) {
        QPoint izq(this->lim_izq,
                   this->lim_sup + i*floor(this->lim_inf/FILAS));
        QPoint der(this->lim_der,
                   this->lim_sup + i*floor(this->lim_inf/FILAS));
        paint.drawLine(izq, der);
    }




}

void GameWindow::keyPressEvent(QKeyEvent *event){

    if (event->key() == Qt::Key_Up || event->key() == Qt::Key_W) {
        this->cola_mov.push(Mov::Up);
    }else if (event->key() == Qt::Key_Left || event->key() == Qt::Key_A) {
        this->cola_mov.push(Mov::Left);
    }else if (event->key() == Qt::Key_Right || event->key() == Qt::Key_D) {
        this->cola_mov.push(Mov::Right);
    }else if (event->key() == Qt::Key_Down || event->key() == Qt::Key_S) {
        this->cola_mov.push(Mov::Down);
    }
}

void GameWindow::mousePressEvent(QMouseEvent *event){

    QDir dir(":/");
    cout << dir.absolutePath().toStdString() << endl;
    QPixmap pix;
    pix.load(":/images/marcador.png");
    marcador.setParent(this);

    if (event->y() > this->lim_sup && event->y() < this->lim_inf &&
            event->x() > this->lim_izq && event->x() < this->lim_der){

        this->setPosMouse(make_pair(event->x()-lim_izq,event->y()-lim_sup));
        // Cambio del origen de coordenadas [0,0] al borde de la cuadricula

        this->col_marcador = (this->getPosMouse().first/this->ancho_casilla);
        this->row_marcador = (this->getPosMouse().second/this->alto_casilla);
        qDebug("Fila: " + QString::number(this->row_marcador).toLatin1() + ", Columna: " + QString::number(this->col_marcador).toLatin1());

        marcador.setPixmap(pix.scaled(this->ancho_casilla,this->alto_casilla));
        marcador.setGeometry(QRect((this->col_marcador*this->ancho_casilla)+this->lim_izq,(this->row_marcador*this->alto_casilla)+this->lim_sup,
                                   this->ancho_casilla,this->alto_casilla));
        marcador.show();
        qDebug(QString::number(marcador.pos().rx()).toLatin1() + ',' +QString::number(marcador.pos().ry()).toLatin1());
    }
}

pair <int,int> GameWindow::getPosMouse(){
    return this->pos_mouse;
}

void GameWindow::setPosMouse(pair <int,int> pos){
    this->pos_mouse.first = pos.first;
    this->pos_mouse.second = pos.second;
}

int GameWindow::getLim_der() { return this->lim_der; }


int GameWindow::getLim_inf() { return this->lim_inf; }


int GameWindow::getLim_izq() { return this->lim_izq; }


int GameWindow::getLim_sup() { return this->lim_sup; }

void GameWindow::printListConsola(QString str) {
    ui->listConsola->addItem(str);
}

void GameWindow::clearListConsola() {
    ui->listConsola->clear();
}

pair<int, int> GameWindow::calculoPosicion(pair<int, int> pos)
{
    int px = this->lim_izq + pos.first*floor((this->lim_der - this->lim_izq)/COLUMNAS);
    int py = this->lim_sup + pos.second*floor((this->lim_inf - this->lim_sup)/FILAS);

    return make_pair(px, py);
}

pair<int, int> GameWindow::calculoPosicion(pair<int, int> pos, pair<int, int> dim)
{
    int px = this->lim_izq + pos.first*floor((this->lim_der - this->lim_izq)/COLUMNAS);
    int py = this->lim_sup + pos.second*floor((this->lim_inf - this->lim_sup)/FILAS);
    int qx = floor(floor((this->lim_der - this->lim_izq)/COLUMNAS - dim.first)/2) + px;
    int qy = floor(floor((this->lim_inf - this->lim_sup)/FILAS - dim.second)/2) + py;
    return make_pair(qx, qy);
}

void GameWindow::introducirBloqueo(pair<int, int> pos)
{

    if (pos.first >= 0 && pos.first < COLUMNAS &&
            pos.second >= 0 && pos.second < FILAS)
    {

        qDebug("Introducido bloqueo en: " + QString::number(pos.first).toLatin1()
               + ", " + QString::number(pos.second).toLatin1() + ";\n");

        QLabel *lay = new QLabel(this);

        QPixmap pix(":/images/obstaculo.png");
        pair<int, int> p_tab = this->calculoPosicion(pos, make_pair(pix.width(), pix.height()));

        lay->setPixmap(pix);
        lay->setGeometry(p_tab.first, p_tab.second, pix.width(), pix.height());
        //lay->setText(QString("HOLA!"));

        this->label_bloqueo.push_back(lay);



    }else qDebug(">> Problemas al inicializar labels de obstáculos <<\n");
}



void GameWindow::setLabel_jugador(QLabel *label_jugador) {
    this->label_jugador.setParent(label_jugador->parentWidget());
    this->label_jugador.setPixmap(*(label_jugador->pixmap()));
    this->label_jugador.setGeometry(label_jugador->geometry());
}

void GameWindow::setLabel_jugadorGeometry(int qx, int qy, int w, int h) {
    this->label_jugador.setGeometry(qx, qy, w, h);
}

void GameWindow::setSaludBar(int v)
{
    if (v >= 0 && v <= 100)
        ui->saludBar->setValue(v);
}

void GameWindow::setEscudoBar(int v)
{
    if (v >= 0 && v <= 100)
        ui->escudoBar->setValue(v);
}

void GameWindow::setAtqBar(int v)
{
    if (v >= 0 && v <= 100)
        ui->atqBar->setValue(v);
}

void GameWindow::setAtqEspBar(int v)
{
    if (v >= 0 && v <= 100)
        ui->atqespBar->setValue(v);
}

int GameWindow::frontMov() {
    return this->cola_mov.front();
}

bool GameWindow::emptyMov() {
    return this->cola_mov.empty();
}

void GameWindow::popMov() {
    this->cola_mov.pop();
}


void GameWindow::closeEvent(QCloseEvent *event) {
    QMessageBox::StandardButton rest = QMessageBox::question ( this, tr("Mensaje de advertencia"),
                                                               tr("Si sales perderás la partida...\n¿Estás seguro?\n"),
                                                               QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                               QMessageBox::Yes);
    if (rest != QMessageBox::Yes) {
        event->ignore();
    }else event->accept();
}


/*
 * ~~~~~~~~~~~~~~~~~** SLOTs **~~~~~~~~~~~~~~~~~
 */

void GameWindow::moverUp()
{
    this->cola_mov.push(Mov::Up);
}

void GameWindow::moverDown()
{
    this->cola_mov.push(Mov::Down);
}

void GameWindow::moverLeft()
{
    this->cola_mov.push(Mov::Left);
}

void GameWindow::moverRight()
{
    this->cola_mov.push(Mov::Right);
}
