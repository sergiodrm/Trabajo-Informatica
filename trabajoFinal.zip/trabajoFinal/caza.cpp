#include "caza.h"

Caza::Caza(): Nave(28, 28, 100, 57, make_pair(0, 0))
{
    this->imagenes[Mov::Up] = QPixmap(":/images/caza_U.png");
    this->imagenes[Mov::Down] = QPixmap(":/images/caza_D.png");
    this->imagenes[Mov::Left] = QPixmap(":/images/caza_L.png");
    this->imagenes[Mov::Right] = QPixmap(":/images/caza_R.png");
    this->key = Mov::Down;
}

void Caza::activarTurbo(){

}
