#include "nave.h"
#include "gamewindow.h"

Nave::Nave()
{
    this->vida = 50;
    this->escudo = 20;
    this->ataque = 4;
    this->ataque_especial = 4;
    this->pos.first = 0;
    this->pos.second = 0;

    this->velocidad = 1;
    this->puntos_accion = PA_MAX;

    this->rango_ataque = 2;

}

Nave::Nave(int vid, int esc, int ataq, int ataq_es, pair<int, int> pos){
    this->vida = vid;
    this->escudo = esc;
    this->ataque = ataq;
    this->ataque_especial = ataq_es;
    if (pos.first >= 0 && pos.first < COLUMNAS){
        this->pos.first = pos.first;
    }else this->pos.first = 0;
    if (pos.second >= 0 && pos.second < FILAS){
        this->pos.second = pos.second;
    }else this->pos.second = 0;

    this->velocidad = 1;
    this->puntos_accion = PA_MAX;

    this->rango_ataque = 2;

}

Nave::Nave(Nave &n) {
    this->vida = n.vida;
    this->escudo = n.escudo;
    this->ataque = n.ataque;
    this->ataque_especial = n.ataque_especial;
    if (pos.first >= 0 && pos.first < COLUMNAS){
        this->pos.first = pos.first;
    }else this->pos.first = 0;
    if (pos.second >= 0 && pos.second < FILAS){
        this->pos.second = pos.second;
    }else this->pos.second = 0;

    this->velocidad = n.velocidad;
    this->puntos_accion = n.puntos_accion;

    this->key = n.key;
    this->imagenes = n.imagenes;
    this->puntos_accion = n.puntos_accion;
    this->rango_ataque = n.rango_ataque;
}

Nave::~Nave(){

}

// Metodos GET
Nave* Nave::getNave() { return this; }
int Nave::getVida() { return vida; }
int Nave::getAtaque() { return ataque; }
int Nave::getAtaque_especial() { return ataque_especial; }
int Nave::getEscudo() { return escudo; }
int Nave::getKey() { return this->key; }
int Nave::getX() { return this->pos.first; }
int Nave::getY() { return this->pos.second; }
int Nave::getPuntos_accion() { return this->puntos_accion; }
int Nave::getRango_ataque() { return this->rango_ataque; }
int Nave::getVelocidad() { return this->velocidad; }
pair<int,int> Nave::getPos() { return this->pos;  }
QPixmap Nave::getImagen() { return this->imagenes[this->key]; }
map<int, QPixmap> Nave::getImagenes() { return this->imagenes; }

// Metodos SET
void Nave::setVida(int value) {
    if ( value > 0 )
    {
        this->vida = value;
    } else this->vida = 0;
}

void Nave::setAtaque(int value){
    if ( value > 0 )
        this->ataque = value;
}

void Nave::setAtaque_especial(int value){
    if ( value > 0 )
        this->ataque_especial = value;
}

void Nave::setEscudo(int value){
    if ( value > 0 )
        this->escudo = value;
}

void Nave::setPos(pair<int, int> pos){
    if (pos.first >= 0 && pos.first < COLUMNAS){
        this->pos.first = pos.first;
    }else this->pos.first = -1;
    if (pos.second >= 0 && pos.second < FILAS){
        this->pos.second = pos.second;
    }else this->pos.second = -1;
}

void Nave::setPuntos_accion(int p) {
    if ( p >= 0 || p <= PA_MAX )
        this->puntos_accion = p;
}

void Nave::setRango_ataque(int rng) {
    if ( rng > 0 )
        this->rango_ataque = rng;
}

void Nave::setVelocidad(int v) {
    if ( v > 0 )
        this->velocidad = v;
}

bool Nave::mover(int mov){

    if ( this->puntos_accion > 0) {
        if (mov == Mov::Up && this->pos.second - this->velocidad >= 0) {
            this->pos.second -= this->velocidad;
        }else if (mov == Mov::Down && this->pos.second + this->velocidad < FILAS){
            this->pos.second += this->velocidad;
        }else if (mov == Mov::Right && this->pos.first + this->velocidad < COLUMNAS) {
            this->pos.first += this->velocidad;
        }else if (mov == Mov::Left && this->pos.first - this->velocidad >= 0) {
            this->pos.first -= this->velocidad;;
        }
        this->key = mov;
    }else return false;

    this->puntos_accion--;
    return true;

}

bool Nave::atacar(Nave *nave_enemiga)
{
    // Mensaje de informacion al usuario
    qDebug("Rango de ataque: " + QString::number(this->rango_ataque).toLatin1() + "\n");

    if ( abs(this->pos.first - nave_enemiga->pos.first) + abs(this->pos.second - nave_enemiga->pos.second) <= this->rango_ataque )
    {
        qDebug("Ataque solicitado");
        nave_enemiga->vida -= this->ataque*(1-nave_enemiga->escudo/100);
        //msg.setInformativeText("Enemigo alcanzado.\n ¡Buen trabajo capitán!");
        qDebug(QString::number(this->rango_ataque).toLatin1());

        this->puntos_accion--;
        return true;

    } else {

        return false;
    }
    //msg.exec();





}
