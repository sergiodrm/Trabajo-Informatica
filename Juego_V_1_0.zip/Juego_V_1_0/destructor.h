#ifndef DESTRUCTOR_H
#define DESTRUCTOR_H

#include "nave.h"


class Destructor : virtual public Nave
{
public:
    Destructor();
    void habilidad(bool value);
};

#endif // DESTRUCTOR_H
